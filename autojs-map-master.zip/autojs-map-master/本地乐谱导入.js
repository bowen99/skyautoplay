var dir = android.os.Environment.getExternalStorageDirectory() + "/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/";
	var dst = android.os.Environment.getExternalStorageDirectory() + "/Android/data/com.Maple.SkyStudio/files/Sheet/";
	var dst2 = android.os.Environment.getExternalStorageDirectory() + "/Documents/SkyAutoPlayer/sheets/"
	var txtFiles = files.listDir(dir, function (name) {
		return name.endsWith(".txt") && files.isFile(files.join(dir, name));
	});
	files.createWithDirs(dst2)
	for (var i in txtFiles) {
		var sheets = dir + txtFiles[i];
		var hw = dst + txtFiles[i];
		var ot = dst2 + txtFiles[i];
		files.copy(sheets, ot)
		files.copy(sheets, hw);

	}