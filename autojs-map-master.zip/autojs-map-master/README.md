# autojs-map

#### 介绍
光遇自动弹琴代码和sheet乐谱

#### 软件架构
下载autojsx软件
https://github.com/kkevsekk1/AutoX/releases


#### 使用说明
可以在mumu模拟用，也可以在手机上用
当然也可以自己制作乐谱，然后用脚本来自动弹奏
https://www.123pan.com/s/1fc7Vv-i68lA.html
用skystudio制作txt乐谱，具体请自行百度。上面是skystudio下载地址
然后把skystudio导出的乐谱移动到脚本乐谱所在位置即可
脚本乐谱所在位置一般在![不同手机可能位置也有不同](uploadimage14.png)
不同手机可能位置也有不同，仔细查找一下即可

![输入图片说明](uploadimage1.png)
![输入图片说明](uploadimage2.png)
![输入图片说明](uploadimage3.png)
![输入图片说明](uploadimage4.png)
![输入图片说明](uploadimage5.png)
![输入图片说明](uploadimage6.png)
根据游戏中琴键的位置，依次点击
![输入图片说明](uploadimage7.png)
![输入图片说明](uploadimage8.png)
我没开游戏，点击最后一个的时候要在游戏界面
![输入图片说明](uploadimage9.png)

当遇到一些问题，一般重启手机就好了

QQ群号：1011622003

